let tahrirlanayotganId = null;


// ===============================
// MAHSULOTLARNI OLISH
// ===============================

async function mahsulotlarniOl() {

    const javob = await fetch('/mahsulotlar');

    barchaMahsulotlar = await javob.json();

    mahsulotlarniChiqar();
    statistika();
}


// ===============================
// MAHSULOTLARNI EKRANGA CHIQARISH
// ===============================

function mahsulotlarniChiqar() {

    const div = document.getElementById('mahsulotlar');

    div.innerHTML = '';

    barchaMahsulotlar.forEach(mahsulot => {

        div.innerHTML += `
            <div class="mahsulot">

                <h3>🤖 ${mahsulot.nomi}</h3>

                <p>
                    📁 Kategoriya:
                    ${mahsulot.kategoriya}
                </p>

                <p>
                    📦 Qoldiq:
                    ${mahsulot.soni} dona
                </p>

                <p>
                    💰 Narxi:
                    ${mahsulot.narxi} so‘m
                </p>

                <div class="mahsulot-buttons">

                    <button
                        onclick="mahsulotniTahrirlash(${mahsulot.id})">
                        ✏️ Tahrirlash
                    </button>

                    <button
                        class="ochirish"
                        onclick="mahsulotniOchirish(${mahsulot.id})">
                        🗑️ O‘chirish
                    </button>

                </div>

            </div>
        `;
    });
}
function statistika() {

    document.getElementById('jamiMahsulot').textContent =
        barchaMahsulotlar.length;

    let jami = 0;

    barchaMahsulotlar.forEach(mahsulot => {
        jami += mahsulot.soni;
    });

    document.getElementById('jamiDona').textContent = jami;
}


// ===============================
// QIDIRUV
// ===============================

document
    .getElementById('qidiruv')
    .addEventListener('input', function () {

        const qidiruv = this.value.toLowerCase();

        const natija = barchaMahsulotlar.filter(mahsulot =>
            mahsulot.nomi.toLowerCase().includes(qidiruv)
        );

        const div = document.getElementById('mahsulotlar');

        div.innerHTML = '';

        natija.forEach(mahsulot => {

            div.innerHTML += `
                <div class="mahsulot">

                    <h3>🤖 ${mahsulot.nomi}</h3>

                    <p>
                        📁 Kategoriya:
                        ${mahsulot.kategoriya}
                    </p>

                    <p>
                        📦 Qoldiq:
                        ${mahsulot.soni} dona
                    </p>

                    <p>
                        💰 Narxi:
                        ${mahsulot.narxi} so‘m
                    </p>

                    <div class="mahsulot-buttons">

                        <button
                            onclick="mahsulotniTahrirlash(${mahsulot.id})">
                            ✏️ Tahrirlash
                        </button>

                        <button
                            class="ochirish"
                            onclick="mahsulotniOchirish(${mahsulot.id})">
                            🗑️ O‘chirish
                        </button>

                    </div>

                </div>
            `;
        });
    });


// ===============================
// YANGI MAHSULOT QO‘SHISH OYNASI
// ===============================

function mahsulotQoshish() {

    tahrirlanayotganId = null;

    document.querySelector('.modal-content h2').textContent =
        '➕ Yangi mahsulot';

    document.getElementById('nomi').value = '';
    document.getElementById('kategoriya').value = '';
    document.getElementById('soni').value = '';
    document.getElementById('narxi').value = '';

    document.getElementById('formaOyna').style.display = 'flex';
}
// ===============================
// MAHSULOTNI TAHRIRLASH
// ===============================

function mahsulotniTahrirlash(id) {

    const mahsulot = barchaMahsulotlar.find(
        mahsulot => mahsulot.id === id
    );

    if (!mahsulot) {
        return;
    }

    tahrirlanayotganId = id;

    document.querySelector('.modal-content h2').textContent =
        '✏️ Mahsulotni tahrirlash';

    document.getElementById('nomi').value =
        mahsulot.nomi;

    document.getElementById('kategoriya').value =
        mahsulot.kategoriya;

    document.getElementById('soni').value =
        mahsulot.soni;

    document.getElementById('narxi').value =
        mahsulot.narxi;

    document.getElementById('formaOyna').style.display =
        'flex';
}


// ===============================
// OYNANI YOPISH
// ===============================

function oynaniYopish() {

    document.getElementById('formaOyna').style.display =
        'none';

    tahrirlanayotganId = null;
}


// ===============================
// SAQLASH
// ===============================

async function mahsulotniSaqlash() {

    const nomi =
        document.getElementById('nomi').value.trim();

    const kategoriya =
        document.getElementById('kategoriya').value.trim();

    const soni =
        Number(document.getElementById('soni').value);

    const narxi =
        Number(document.getElementById('narxi').value);


    if (
        nomi === '' ||
        kategoriya === '' ||
        soni <= 0 ||
        narxi <= 0
    ) {

        alert("Iltimos, barcha maydonlarni to‘g‘ri to‘ldiring!");

        return;
    }


    try {

        // ===============================
        // TAHRIRLASH
        // ===============================

        if (tahrirlanayotganId !== null) {

            const javob = await fetch(
                `/mahsulotlar/${tahrirlanayotganId}`,
                {
                    method: 'PUT',

                    headers: {
                        'Content-Type': 'application/json'
                    },

                    body: JSON.stringify({
                        nomi: nomi,
                        kategoriya: kategoriya,
                        soni: soni,
                        narxi: narxi
                    })
                }
            );

            const natija = await javob.json();

            alert(natija.xabar);

        }

        // ===============================
        // YANGI MAHSULOT QO‘SHISH
        // ===============================

        else {

            const javob = await fetch('/mahsulotlar', {

                method: 'POST',

                headers: {
                    'Content-Type': 'application/json'
                },

                body: JSON.stringify({
                    nomi: nomi,
                    kategoriya: kategoriya,
                    soni: soni,
                    narxi: narxi
                })
            });

            const natija = await javob.json();

            alert(natija.xabar);
        }


        // Formani tozalash

        document.getElementById('nomi').value = '';
        document.getElementById('kategoriya').value = '';
        document.getElementById('soni').value = '';
        document.getElementById('narxi').value = '';

        oynaniYopish();

        mahsulotlarniOl();

    } catch (xato) {

        console.error(xato);

        alert("Server bilan bog‘lanishda xatolik!");
    }
}
// ===============================
// MAHSULOTNI O‘CHIRISH
// ===============================

async function mahsulotniOchirish(id) {

    const tasdiq = confirm(
        "Bu mahsulotni o‘chirishni xohlaysizmi?"
    );

    if (!tasdiq) {
        return;
    }


    try {

        const javob = await fetch(
            `/mahsulotlar/${id}`,
            {
                method: 'DELETE'
            }
        );

        const natija = await javob.json();

        alert(natija.xabar);

        mahsulotlarniOl();

    } catch (xato) {

        console.error(xato);

        alert("Mahsulotni o‘chirishda xatolik!");
    }
}


// ===============================
// SAYT OCHILGANDA
// ===============================

mahsulotlarniOl();